from django.urls import path
from .views import *

urlpatterns = [
    path('', home, name='home'),
    path('color/<int:color_id>/', filter_by_color, name='filter_by_color'),
    path('brand/<int:brand_id>/', filter_by_brand, name='filter_by_brand'),
    path('car/<int:car_id>/', car_detail, name='car_detail'),
    path('car/<int:car_id>/comment/', add_comment, name='add_comment'),
    path('register/', register, name='register'),
    path('login/', user_login, name='login'),
    path('logout/', user_logout, name='logout'),
]
