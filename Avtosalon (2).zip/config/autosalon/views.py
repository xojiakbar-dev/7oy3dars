from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .models import Car, Color, Brand, Comment
from django.http import JsonResponse


def home(request):
    cars = Car.objects.all()
    return render(request, 'cars/home.html', {'cars': cars})

def filter_by_color(request, color_id):
    cars = Car.objects.filter(color_id=color_id)
    return render(request, 'cars/home.html', {'cars': cars})


def filter_by_brand(request, brand_id):
    cars = Car.objects.filter(brand_id=brand_id)
    return render(request, 'cars/home.html', {'cars': cars})


def car_detail(request, car_id):
    car = get_object_or_404(Car, id=car_id)
    return render(request, 'cars/car_detail.html', {'car': car})


def add_comment(request, car_id):
    if request.method == "POST":
        text = request.POST.get("text")
        car = get_object_or_404(Car, id=car_id)
        comment = Comment.objects.create(user=request.user, car=car, text=text)
        return redirect('car_detail', car_id=car.id)
    return JsonResponse({"error": "Invalid request"}, status=400)

def register(request):
    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('home')
    else:
        form = UserCreationForm()
    return render(request, 'cars/register.html', {'form': form})


def user_login(request):
    if request.method == "POST":
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('home')
    else:
        form = AuthenticationForm()
    return render(request, 'cars/login.html', {'form': form})


def user_logout(request):
    logout(request)
    return redirect('home')
