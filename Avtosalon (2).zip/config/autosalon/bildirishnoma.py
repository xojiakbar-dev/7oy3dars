from django.db.models.signals import post_save
from django.dispatch import receiver
from django.core.mail import send_mail
from django.conf import settings
from .models import Car

@receiver(post_save, sender=Car)
def send_new_car_email(sender, instance, created, **kwargs):
    if created:
        subject = f"Yangi mashina qo‘shildi: {instance.name}"
        message = f"Yangi {instance.brand.name} {instance.name} mashinasi bazaga qo‘shildi!"
        recipient_list = [settings.DEFAULT_ADMIN_EMAIL]
        send_mail(subject, message, settings.EMAIL_HOST_USER, recipient_list)
