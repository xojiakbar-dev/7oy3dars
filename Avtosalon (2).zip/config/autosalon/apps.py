from django.apps import AppConfig


class AutosalonConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'autosalon'

    def send(self):
        import bildirishnoma


